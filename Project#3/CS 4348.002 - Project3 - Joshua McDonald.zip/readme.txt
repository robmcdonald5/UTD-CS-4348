COMPILATION COMMAND
	// compilation command
	javac MemoryBlock.java MemoryAllocator.java Main.java

	// program run command
	java Main
	~Enter the name of the input file: "input.txt or any other input test files"

FILES
	input.txt
	readme.txt

	Main.java
	MemoryAllocator.java
	MemoryBlock.java