COMPILATION COMMAND
	g++ -std=c++11 Project1.cpp -o run
	(This will not compile if the C++ version is not specified in Linux)

	./run sample1.txt 30
	./run sample2.txt 30
	./run sample3.txt 30
	./run sample4.txt 30
	./run sample5.txt 30

FILES
	sample1.txt, sample2.txt, sample3.txt, sample4.txt, sample5.txt
	Summary.word
	Project1.cpp