COMPILATION COMMAND
	// compilation command
	javac Main.java Customer.java PostalWorker.java Scales.java

	// program run command (this should ensure enough memory on the JVM to run the program)
	java -Xmx2g Main

FILES
	design.docx
	summary.docx
	readme.txt

	Main.java
	Customer.java
	PostalWorker.java
	Scales.java